/*
* Title: DictionarySearchTree.cpp
* Author: Deniz Semih �zal
* ID: 21802414
* Section: 1
* Assignment: 3
* Description: This file is a cpp file of DictionarySearchTree.cpp
*/
#include "DictionarySearchTree.h"
DictionarySearchTree::DictionarySearchTree(string dictionaryFile) {
	
}
DictionarySearchTree::~DictionarySearchTree() {

}

void DictionarySearchTree::insert(string word) {
	
}

void DictionarySearchTree::search(string word, int& numComparisons, bool& found) const {

}

void DictionarySearchTree::search(string queryFile, string outputFile) const {

}

