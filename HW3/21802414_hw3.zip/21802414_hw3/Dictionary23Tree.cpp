/*
* Title: Dictionary23Tree.cpp
* Author: Deniz Semih �zal
* ID: 21802414
* Section: 1
* Assignment: 3
* Description: (I could not do this part)
*/
#include "Dictionary23Tree.h"

