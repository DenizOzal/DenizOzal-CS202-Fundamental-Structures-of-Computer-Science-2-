#pragma once
/*
* Title: Dictionary23Tree.h
* Author: Deniz Semih �zal
* ID: 21802414
* Section: 1
* Assignment: 3
* Description: (I could not do this part)
*/

class Dictionary23Tree 
{
public:
	
};

